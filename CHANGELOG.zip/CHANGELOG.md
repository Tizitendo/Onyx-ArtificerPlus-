## 1.3.0
* fix error that spammed the console
* added small cooldown to artis Nanobomb to prevent an accidental second use