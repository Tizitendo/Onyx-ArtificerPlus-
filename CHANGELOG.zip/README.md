# Onyx-ArtificerPlus

- holding attack is now the same speed as spamming it (default: disabled)
- gave Artificer a weak hover when Jump is held 
- decreased tectonic surge cooldown and increased surge distance (default: disabled)
- localised sun now has different speed depending on if the special button is held
- fix nanospear firing when pulsing it while having another charge
- add small cooldown to Nanobomb to avoid accidentally using a second one (does not affect the normal cooldown)

## Special Thanks To
* Miguelito for the original ArtificerImprovements mod and helping a ton with problems and code cleanup
* The Return Of Modding Discord

## Contact
For questions or bug reports, you can find us in the [RoRR Modding Server](https://discord.gg/VjS57cszMq) @Onyx
